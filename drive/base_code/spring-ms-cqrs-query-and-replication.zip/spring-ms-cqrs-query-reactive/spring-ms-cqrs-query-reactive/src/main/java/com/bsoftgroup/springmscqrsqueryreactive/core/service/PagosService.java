package com.bsoftgroup.springmscqrsqueryreactive.core.service;

import org.springframework.stereotype.Service;

import com.bsoftgroup.springmscqrsqueryreactive.core.dao.PagosNoSqlReactiveFacadeInterface;
import com.bsoftgroup.springmscqrsqueryreactive.core.dao.nosql.Pagos;

import reactor.core.publisher.Flux;


@Service
public class PagosService implements PagosServiceInterface{
	
	private final PagosNoSqlReactiveFacadeInterface nosql;
	
	

	public PagosService(PagosNoSqlReactiveFacadeInterface nosql) {
		this.nosql = nosql;
	}



	@Override
	public Flux<Pagos> buscarPagos() {
		// TODO Auto-generated method stub
		return this.nosql.buscarPagos();
	}
	

}
