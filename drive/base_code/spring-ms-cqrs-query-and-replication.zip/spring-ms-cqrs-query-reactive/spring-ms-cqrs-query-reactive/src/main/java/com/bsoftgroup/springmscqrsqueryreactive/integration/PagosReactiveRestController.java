package com.bsoftgroup.springmscqrsqueryreactive.integration;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bsoftgroup.springmscqrsqueryreactive.core.dao.nosql.Pagos;
import com.bsoftgroup.springmscqrsqueryreactive.core.service.PagosServiceInterface;

import reactor.core.publisher.Flux;

@RestController
public class PagosReactiveRestController {
	
	private final PagosServiceInterface service;
	
	
	
	
	public PagosReactiveRestController(PagosServiceInterface service) {
		this.service = service;
	}




	@GetMapping(path = "/obtener/pagos")
	public Flux<Pagos> obtenerPagos(){
		return this.service.buscarPagos();
	}

}
