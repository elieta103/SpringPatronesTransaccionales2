package com.bsoftgroup.springmscqrsqueryreactive.core.dao.nosql;

import org.springframework.data.mongodb.repository.Query;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;





public interface ReactivePagosRepository extends ReactiveCrudRepository<Pagos, String>{

}

/*
public interface ReactivePersonRepository extends ReactiveCrudRepository<Usuario, String>{
	 
	  Mono<Usuario> findByUsername(String username);

	  @Query("{ 'username': ?admin}")
	  Flux<Usuario> findByUsernameQuery(String username);

}
*/


