package com.bsoftgroup.springmscqrsqueryreactive.core.dao;

import org.springframework.stereotype.Repository;

import com.bsoftgroup.springmscqrsqueryreactive.core.dao.nosql.Pagos;
import com.bsoftgroup.springmscqrsqueryreactive.core.dao.nosql.ReactivePagosRepository;

import reactor.core.publisher.Flux;


@Repository
public class PagosNoSqlReactiveFacade implements PagosNoSqlReactiveFacadeInterface {
	
	private final ReactivePagosRepository nosql;
	
	

	public PagosNoSqlReactiveFacade(ReactivePagosRepository nosql) {
		this.nosql = nosql;
	}



	@Override
	public Flux<Pagos> buscarPagos() {
		// TODO Auto-generated method stub
		return this.nosql.findAll();
	}
	
	

}
