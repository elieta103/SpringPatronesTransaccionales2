package com.bsoftgroup.springmscqrsqueryreactive.core.dao;

import com.bsoftgroup.springmscqrsqueryreactive.core.dao.nosql.Pagos;

import reactor.core.publisher.Flux;

public interface PagosNoSqlReactiveFacadeInterface {
	
	public Flux<Pagos> buscarPagos();

}
