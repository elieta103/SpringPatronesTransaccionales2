package com.bsoftgroup.springmscqrsqueryreactive.core.service;

import com.bsoftgroup.springmscqrsqueryreactive.core.dao.nosql.Pagos;

import reactor.core.publisher.Flux;

public interface PagosServiceInterface {
	
	public Flux<Pagos> buscarPagos();

}
