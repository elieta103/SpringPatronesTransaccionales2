package com.bsoftgroup.springmscqrscommandabono;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringMsCqrsCommandAbonoApplicationTests {

	@Test
	void contextLoads() {
	}

}
