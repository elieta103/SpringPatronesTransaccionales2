package com.bsoftgroup.springmscqrscommandabono.integration;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.bsoftgroup.springmscqrscommandabono.configuration.AppException;
import com.bsoftgroup.springmscqrscommandabono.core.business.AbonoNegocioInterface;
import com.bsoftgroup.springmscqrscommandabono.dto.AbonoDto;
import com.bsoftgroup.springmscqrscommandabono.dto.TransaccionDto;


@RestController
public class AbonoRestController {
	
	private Logger logger = LoggerFactory.getLogger(AbonoRestController.class);
	
	@Autowired
	private AbonoNegocioInterface service;
	
	@PostMapping(path = "/procesar/abono/to/recaudador")
    public TransaccionDto procesarAbono(@RequestBody AbonoDto abono) throws AppException{
		
		logger.info("procesarAbono ", "-");
		return service.procesarAbono(abono.getCuenta(), abono.getMonto(), abono.getCliente(), abono.getTransaccion(), abono.getCausal(), abono.getPagador());
	}	

}