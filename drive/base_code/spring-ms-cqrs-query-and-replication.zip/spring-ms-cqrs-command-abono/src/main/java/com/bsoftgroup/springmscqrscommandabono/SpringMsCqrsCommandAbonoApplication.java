package com.bsoftgroup.springmscqrscommandabono;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringMsCqrsCommandAbonoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringMsCqrsCommandAbonoApplication.class, args);
	}

}
