package com.bsoftgroup.springmscqrscommandabono.core.business;

import java.math.BigDecimal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bsoftgroup.springmscqrscommandabono.configuration.AppException;
import com.bsoftgroup.springmscqrscommandabono.core.dao.AbonoDaoInterface;
import com.bsoftgroup.springmscqrscommandabono.dto.TransaccionDto;


@Service
public class AbonoBusiness implements AbonoNegocioInterface{
	
	@Autowired
	private AbonoDaoInterface dao;

	@Override
	public TransaccionDto procesarAbono(String cuenta, BigDecimal monto, String cliente, String transaccion,
			String causal, String pagador) throws AppException {
		// TODO Auto-generated method stub
		return dao.procesarAbono(cuenta, monto, cliente, transaccion, causal, pagador);
	}

}