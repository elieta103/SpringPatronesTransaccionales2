package com.bsoftgroup.springmscqrscommandabono.core.business;

import java.math.BigDecimal;

import com.bsoftgroup.springmscqrscommandabono.configuration.AppException;
import com.bsoftgroup.springmscqrscommandabono.dto.TransaccionDto;



public interface AbonoNegocioInterface {
	
	public TransaccionDto procesarAbono(String cuenta,BigDecimal monto, String cliente,String transaccion,String causal,String pagador) throws AppException;

}