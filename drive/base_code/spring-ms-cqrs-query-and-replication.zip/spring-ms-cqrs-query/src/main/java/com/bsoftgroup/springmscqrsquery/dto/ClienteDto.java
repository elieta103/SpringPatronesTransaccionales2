package com.bsoftgroup.springmscqrsquery.dto;


public class ClienteDto {
	  private Integer codigo;
	  private String nombres;
	  
	  
	  
	  
	public ClienteDto(Integer codigo, String nombres) {
		super();
		this.codigo = codigo;
		this.nombres = nombres;
	}

	public Integer getCodigo() {
		return codigo;
	}
	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}
	public String getNombres() {
		return nombres;
	}
	public void setNombres(String nombres) {
		this.nombres = nombres;
	}
	  
	  
	}