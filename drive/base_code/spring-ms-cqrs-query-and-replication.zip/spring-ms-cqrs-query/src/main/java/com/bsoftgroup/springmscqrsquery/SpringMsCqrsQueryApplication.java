package com.bsoftgroup.springmscqrsquery;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringMsCqrsQueryApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringMsCqrsQueryApplication.class, args);
	}

}
