package com.bsoftgroup.springmscqrsquery.core.dao;

import java.util.List;


import com.bsoftgroup.springmscqrsquery.configuration.AppException;
import com.bsoftgroup.springmscqrsquery.core.dao.nosql.Pagos;


public interface ConsultaFacadeDaoInterface {
	
	public List<Pagos> obtenerPagos() throws AppException;

}
