package com.bsoftgroup.springmscqrsquery.integration;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.bsoftgroup.springmscqrsquery.configuration.AppException;
import com.bsoftgroup.springmscqrsquery.core.business.ConsultaBusinessInterface;
import com.bsoftgroup.springmscqrsquery.core.dao.nosql.Pagos;
import com.bsoftgroup.springmscqrsquery.dto.DeudaDto;

@RestController
public class ConsultaRestController {
	
	
	private final ConsultaBusinessInterface service;
	
	 private Logger log = LoggerFactory.getLogger(getClass());
	
	
	public ConsultaRestController(ConsultaBusinessInterface service) {
		
		this.service = service;
	}




	 @GetMapping(path = "/obtener/pagos")
		public ResponseEntity<List<Pagos>> obtenerPagos(){
		 
		 List<Pagos> pagos =new ArrayList<>();
		
			
		 log.info("obtenerPagos");
			
			try {
				pagos = this.service.obtenerPagos();
				if(!pagos.isEmpty()) {
					return new ResponseEntity<List<Pagos>>(pagos,HttpStatus.OK);
				}else {
					return new ResponseEntity<List<Pagos>>(pagos,HttpStatus.NO_CONTENT);
				}
				
			}catch (Exception e) {
				return new ResponseEntity<List<Pagos>>(HttpStatus.INTERNAL_SERVER_ERROR);
			}
			
		}

}
