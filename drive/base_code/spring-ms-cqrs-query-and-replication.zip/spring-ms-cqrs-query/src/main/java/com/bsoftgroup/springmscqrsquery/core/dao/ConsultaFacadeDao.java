package com.bsoftgroup.springmscqrsquery.core.dao;

import java.util.List;

import org.springframework.stereotype.Component;

import com.bsoftgroup.springmscqrsquery.configuration.AppException;
import com.bsoftgroup.springmscqrsquery.core.dao.nosql.NoSQLDaoInterface;
import com.bsoftgroup.springmscqrsquery.core.dao.nosql.Pagos;

@Component
public class ConsultaFacadeDao implements ConsultaFacadeDaoInterface {
	

	
	private final NoSQLDaoInterface nosql;

	public ConsultaFacadeDao( NoSQLDaoInterface nosql) {

		this.nosql = nosql;
		
	}




	@Override
	public List<Pagos> obtenerPagos() throws AppException {
		// TODO Auto-generated method stub
		return this.nosql.findAll();
	}

}
