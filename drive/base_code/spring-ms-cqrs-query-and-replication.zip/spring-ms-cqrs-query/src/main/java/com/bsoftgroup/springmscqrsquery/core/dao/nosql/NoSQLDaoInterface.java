package com.bsoftgroup.springmscqrsquery.core.dao.nosql;

import org.springframework.data.mongodb.repository.MongoRepository;








public interface NoSQLDaoInterface extends MongoRepository<Pagos,String>{

	

}
