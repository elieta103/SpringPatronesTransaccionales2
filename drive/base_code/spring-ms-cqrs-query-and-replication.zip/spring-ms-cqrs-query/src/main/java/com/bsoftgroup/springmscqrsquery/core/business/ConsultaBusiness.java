package com.bsoftgroup.springmscqrsquery.core.business;

import java.util.List;

import org.springframework.stereotype.Service;

import com.bsoftgroup.springmscqrsquery.configuration.AppException;
import com.bsoftgroup.springmscqrsquery.core.dao.ConsultaFacadeDaoInterface;
import com.bsoftgroup.springmscqrsquery.core.dao.nosql.Pagos;
import com.bsoftgroup.springmscqrsquery.dto.DeudaDto;

@Service
public class ConsultaBusiness implements ConsultaBusinessInterface{
	
	private final ConsultaFacadeDaoInterface dao;
	

	public ConsultaBusiness(ConsultaFacadeDaoInterface dao) {
		this.dao = dao;
	}





	@Override
	public List<Pagos> obtenerPagos() throws AppException {
		// TODO Auto-generated method stub
		return dao.obtenerPagos();
	}

}
