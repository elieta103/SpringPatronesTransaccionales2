package com.bsoftgroup.springmscqrsquery.core.business;

import java.util.List;

import com.bsoftgroup.springmscqrsquery.configuration.AppException;
import com.bsoftgroup.springmscqrsquery.core.dao.nosql.Pagos;

public interface ConsultaBusinessInterface {
	

	public List<Pagos> obtenerPagos() throws AppException;

}
