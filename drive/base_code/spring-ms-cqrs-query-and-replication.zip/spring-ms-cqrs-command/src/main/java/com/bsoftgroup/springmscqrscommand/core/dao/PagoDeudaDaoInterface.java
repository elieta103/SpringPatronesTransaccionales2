package com.bsoftgroup.springmscqrscommand.core.dao;


import org.springframework.web.bind.annotation.PathVariable;

import com.bsoftgroup.springmscqrscommand.configuration.AppException;
import com.bsoftgroup.springmscqrscommand.dto.AbonoDto;
import com.bsoftgroup.springmscqrscommand.dto.CargoDto;
import com.bsoftgroup.springmscqrscommand.dto.TransaccionDto;



public interface PagoDeudaDaoInterface {
	
	public TransaccionDto procesarAbono(AbonoDto abono);
	public TransaccionDto generarCargoCuenta(CargoDto datosCargo);
	public String getIdTransaccionPago() throws AppException;
	public TransaccionDto revertirAbono( String trasaccion );
	public TransaccionDto revertirCargo( String trasaccion );

}
