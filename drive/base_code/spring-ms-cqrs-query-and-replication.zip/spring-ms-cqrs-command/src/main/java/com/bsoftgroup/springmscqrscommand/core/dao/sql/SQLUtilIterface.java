package com.bsoftgroup.springmscqrscommand.core.dao.sql;

import com.bsoftgroup.springmscqrscommand.configuration.AppException;

public interface SQLUtilIterface {
	
	public String getIdTransaccionPago() throws AppException;

}
