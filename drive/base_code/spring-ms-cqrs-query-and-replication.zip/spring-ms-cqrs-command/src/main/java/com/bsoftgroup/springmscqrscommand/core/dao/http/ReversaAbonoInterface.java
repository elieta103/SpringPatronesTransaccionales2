package com.bsoftgroup.springmscqrscommand.core.dao.http;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.bsoftgroup.springmscqrscommand.dto.TransaccionDto;




@FeignClient(name="spring-ms-cqrs-command-abono-reversa")
public interface ReversaAbonoInterface {
	

	
	@GetMapping(path = "/abono/idtransaccion/{transaccion}")
	public TransaccionDto revertirAbono(@PathVariable("transaccion") String trasaccion );
}
