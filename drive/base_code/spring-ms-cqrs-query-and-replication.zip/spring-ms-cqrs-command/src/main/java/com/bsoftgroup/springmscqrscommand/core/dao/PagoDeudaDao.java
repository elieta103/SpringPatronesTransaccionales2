package com.bsoftgroup.springmscqrscommand.core.dao;

import org.springframework.stereotype.Repository;

import com.bsoftgroup.springmscqrscommand.configuration.AppException;
import com.bsoftgroup.springmscqrscommand.core.dao.http.PagoCallAbonoDaoInterface;
import com.bsoftgroup.springmscqrscommand.core.dao.http.PagoCallCargoDaoInterface;
import com.bsoftgroup.springmscqrscommand.core.dao.http.ReversaAbonoInterface;
import com.bsoftgroup.springmscqrscommand.core.dao.http.ReversaCargoInterface;
import com.bsoftgroup.springmscqrscommand.core.dao.sql.SQLUtilIterface;
import com.bsoftgroup.springmscqrscommand.dto.AbonoDto;
import com.bsoftgroup.springmscqrscommand.dto.CargoDto;
import com.bsoftgroup.springmscqrscommand.dto.TransaccionDto;


@Repository
public class PagoDeudaDao implements PagoDeudaDaoInterface{
	
	private final PagoCallAbonoDaoInterface httpabono;
	
	private final PagoCallCargoDaoInterface httpcargo;
	
	private final ReversaAbonoInterface httpreversaabono;
	
	private final ReversaCargoInterface httpreversacargo;
	
	private final SQLUtilIterface sqlutil;
	
	public PagoDeudaDao(PagoCallCargoDaoInterface httpcargo, PagoCallAbonoDaoInterface httpabono, SQLUtilIterface sqlutil, ReversaCargoInterface httpreversacargo, ReversaAbonoInterface httpreversaabono) {
		this.httpabono = httpabono;
		this.httpcargo = httpcargo;
		this.httpreversaabono = httpreversaabono;
		this.httpreversacargo = httpreversacargo;
		this.sqlutil = sqlutil;
		
	}
	
	@Override
	public TransaccionDto procesarAbono(AbonoDto abono) {
		// TODO Auto-generated method stub
		return this.httpabono.procesarAbono(abono);
	}

	@Override
	public TransaccionDto generarCargoCuenta(CargoDto datosCargo) {
		// TODO Auto-generated method stub
		return this.httpcargo.generarCargoCuenta(datosCargo);
	}

	@Override
	public String getIdTransaccionPago() throws AppException {
		// TODO Auto-generated method stub
		return this.sqlutil.getIdTransaccionPago();
	}

	@Override
	public TransaccionDto revertirAbono(String trasaccion) {
		// TODO Auto-generated method stub
		return this.httpreversaabono.revertirAbono(trasaccion);
	}

	@Override
	public TransaccionDto revertirCargo(String trasaccion) {
		// TODO Auto-generated method stub
		return this.httpreversacargo.revertirCargo(trasaccion);
	}

}
