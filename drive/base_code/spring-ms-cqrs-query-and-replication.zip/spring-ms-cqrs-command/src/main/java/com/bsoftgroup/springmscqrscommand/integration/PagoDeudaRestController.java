package com.bsoftgroup.springmscqrscommand.integration;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.bsoftgroup.springmscqrscommand.core.business.PagoDeudaBusinessInterface;
import com.bsoftgroup.springmscqrscommand.dto.PagoDto;
import com.bsoftgroup.springmscqrscommand.dto.TransaccionDto;

@RestController
public class PagoDeudaRestController {
	
	private final PagoDeudaBusinessInterface service;
	
	
	public PagoDeudaRestController(PagoDeudaBusinessInterface service) {
		this.service = service;}
	

	
	@PostMapping(path = "/procesar/cargo/abono")
	public TransaccionDto generarCargoCuenta(@RequestBody PagoDto pago) {
		
		return service.procesarPago(pago);
		
	}

}
