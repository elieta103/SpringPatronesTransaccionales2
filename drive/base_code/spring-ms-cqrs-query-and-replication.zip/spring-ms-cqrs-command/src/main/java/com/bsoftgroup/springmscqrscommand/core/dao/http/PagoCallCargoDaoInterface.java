package com.bsoftgroup.springmscqrscommand.core.dao.http;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.bsoftgroup.springmscqrscommand.dto.CargoDto;
import com.bsoftgroup.springmscqrscommand.dto.TransaccionDto;



@FeignClient(name="spring-ms-cqrs-command-cargo")
public interface PagoCallCargoDaoInterface {
	
	@PostMapping(path = "/mscqrscargo/procesar/cargo/to/client")
	public TransaccionDto generarCargoCuenta(@RequestBody CargoDto datosCargo);

}