package com.bsoftgroup.springmscqrscommand;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

@SpringBootApplication
@EnableFeignClients("com.bsoftgroup.springmscqrscommand.core.dao.http")
public class SpringMsCqrsCommandApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringMsCqrsCommandApplication.class, args);
	}

}
