package com.bsoftgroup.springmscqrscommand.core.dao.http;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.bsoftgroup.springmscqrscommand.dto.AbonoDto;
import com.bsoftgroup.springmscqrscommand.dto.TransaccionDto;



@FeignClient(name="spring-ms-cqrs-command-abono")
public interface PagoCallAbonoDaoInterface {
	
	@PostMapping(path = "/mscqrsabono/procesar/abono/to/recaudador")
    public TransaccionDto procesarAbono(@RequestBody AbonoDto abono);

}