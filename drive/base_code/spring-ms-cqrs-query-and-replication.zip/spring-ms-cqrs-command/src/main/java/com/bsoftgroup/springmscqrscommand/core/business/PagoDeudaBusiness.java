package com.bsoftgroup.springmscqrscommand.core.business;

import org.springframework.stereotype.Service;

import com.bsoftgroup.springmscqrscommand.configuration.AppException;
import com.bsoftgroup.springmscqrscommand.core.dao.PagoDeudaDaoInterface;
import com.bsoftgroup.springmscqrscommand.core.dao.kafka.Publicador;
import com.bsoftgroup.springmscqrscommand.dto.AbonoDto;
import com.bsoftgroup.springmscqrscommand.dto.CargoDto;
import com.bsoftgroup.springmscqrscommand.dto.PagoDto;
import com.bsoftgroup.springmscqrscommand.dto.TransaccionDto;
import com.fasterxml.jackson.core.JsonProcessingException;

@Service
public class PagoDeudaBusiness implements PagoDeudaBusinessInterface {
	
	private final PagoDeudaDaoInterface dao;
	
	private final Publicador kafka;
	
	public PagoDeudaBusiness(PagoDeudaDaoInterface dao, Publicador kafka) {
	this.dao = dao;
	this.kafka = kafka;
	}


	@Override
	public TransaccionDto procesarPago(PagoDto pago) {
		// TODO Auto-generated method stub
		String idTransaccion=null;
		TransaccionDto tx =  new TransaccionDto();
		tx.setCodigo("000");
		tx.setDescripcion("Proceso de Cargo y Abono Conforme");

		try {
			idTransaccion = dao.getIdTransaccionPago();
		} catch (AppException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			tx.setCodigo("898");
			tx.setDescripcion("Error al generar id de transacción única");
			
			
			return tx; 
		}
		
		
		
		
        CargoDto cargo  =  new CargoDto();
		
		
		cargo.setAcreedor(pago.getAcreedor());
		cargo.setCausal(pago.getCausal());
		cargo.setCliente(pago.getPagador());
		cargo.setCuenta(pago.getCuentacargo());
		cargo.setMonto(pago.getMonto());
		cargo.setTransaccion(idTransaccion);
		TransaccionDto txcargo =null;
		try {
			
			txcargo = dao.generarCargoCuenta(cargo);
			
		}catch (Exception e) {
			//llamo reversa cargo
			tx.setCodigo("697");
			tx.setDescripcion("Error al procesar el cargo");
			//llamada a revertir;
			//dao.revertirCargo(idTransaccion);
			return tx;
		}
		
		if(txcargo.getCodigo().equals("000")) {
			
			AbonoDto abono = new AbonoDto();
			abono.setCausal(pago.getCausal());
			abono.setCliente(pago.getAcreedor());
			abono.setCuenta(pago.getCuentaabono());
			abono.setMonto(pago.getMonto());
			abono.setPagador(pago.getPagador());
			abono.setTransaccion(idTransaccion);
			
			
			TransaccionDto txabono=null;
			try {
				txabono = dao.procesarAbono(abono);
				
			}catch (Exception e) {
				//llamo reversa abono
				//dao.revertirAbono(idTransaccion);
				//dao.revertirCargo(idTransaccion);
				tx.setCodigo("698");
				tx.setDescripcion("Error al procesar el abono");
				return tx;
			}

			
            if(txabono.getCodigo().equals("000")) {
				
				tx.setCodigo("000");
				tx.setDescripcion("Proceso de Cargo y Abono Conforme");
				tx.setIdgenerado(idTransaccion);
				try {
					kafka.eventoPago(pago, Integer.valueOf(idTransaccion));
				} catch (JsonProcessingException | NumberFormatException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
            }else {
				//llamo reversa abono
				//dao.revertirAbono(idTransaccion);
				//dao.revertirCargo(idTransaccion);
				tx.setCodigo("698");
				tx.setDescripcion("Error al procesar el abono");
				return tx;
			}
			
		}else {
			//llamo reversa cargo
			tx.setCodigo("697");
			tx.setDescripcion("Error al procesar el cargo");
			//dao.revertirCargo(idTransaccion);
			return tx;
		}
		
		return tx;
		
		
	}



	
	
}
