package com.bsoftgroup.springmscqrscommand.core.business;

import com.bsoftgroup.springmscqrscommand.dto.PagoDto;
import com.bsoftgroup.springmscqrscommand.dto.TransaccionDto;

public interface PagoDeudaBusinessInterface {
	
	public TransaccionDto procesarPago(PagoDto pago);
}
