package com.bsoftgroup.springmscqrscommand;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringMsCqrsCommandApplicationTests {

	@Test
	void contextLoads() {
	}

}
