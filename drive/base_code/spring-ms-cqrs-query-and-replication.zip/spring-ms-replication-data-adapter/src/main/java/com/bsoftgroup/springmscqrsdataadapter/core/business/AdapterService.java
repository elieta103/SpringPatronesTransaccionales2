package com.bsoftgroup.springmscqrsdataadapter.core.business;



import org.springframework.stereotype.Service;

import com.bsoftgroup.springmscqrsdataadapter.configuration.AppException;
import com.bsoftgroup.springmscqrsdataadapter.core.dao.AdapterFacadeInterface;
import com.bsoftgroup.springmscqrsdataadapter.core.dao.nosql.Pagos;

import com.bsoftgroup.springmscqrsdataadapter.dto.TransaccionDto;

@Service
public class AdapterService implements AdapterServiceInterface {
	
	private final AdapterFacadeInterface dao;
	
	

	public AdapterService(AdapterFacadeInterface dao) {

		this.dao = dao;
	}







	@Override
	public TransaccionDto guardarPagos(Pagos pago) throws AppException {
		// TODO Auto-generated method stub
		return dao.guardarPagos(pago);
	}
	
	

}
