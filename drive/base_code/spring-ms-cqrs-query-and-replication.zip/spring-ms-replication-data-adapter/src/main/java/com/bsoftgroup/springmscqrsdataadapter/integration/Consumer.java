package com.bsoftgroup.springmscqrsdataadapter.integration;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

import com.bsoftgroup.springmscqrsdataadapter.configuration.AppException;
import com.bsoftgroup.springmscqrsdataadapter.core.business.AdapterServiceInterface;
import com.bsoftgroup.springmscqrsdataadapter.core.dao.nosql.Pagos;
import com.bsoftgroup.springmscqrsdataadapter.dto.ClienteDto;
import com.bsoftgroup.springmscqrsdataadapter.dto.DeudaDto;
import com.bsoftgroup.springmscqrsdataadapter.dto.PagoDto;
import com.bsoftgroup.springmscqrsdataadapter.dto.ProductoDto;
import com.bsoftgroup.springmscqrsdataadapter.dto.TransaccionDto;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class Consumer {
	Logger logger = LoggerFactory.getLogger(Consumer.class);
	
	@Autowired
    ObjectMapper objectMapper;
	
	@Autowired
	private AdapterServiceInterface service;
	
	@KafkaListener(topics = {"pago-events-replicate"})
	public void onMessage(ConsumerRecord<Integer,String> consumerRecord) throws JsonProcessingException {
		logger.info("ConsumerRecord : {} ", consumerRecord );
        //libraryEventsService.processLibraryEvent(consumerRecord);
    	PagoDto pagoDto = objectMapper.readValue(consumerRecord.value(), PagoDto.class);
    	
    	//Pagos pago = objectMapper.readValue(consumerRecord.value(), Pagos.class);
    	
    	Pagos pago = new Pagos();
    	pago.setAcreedor(pagoDto.getAcreedor());
    	pago.setCausal(pagoDto.getCausal());
    	pago.setCuentaabono(pagoDto.getCuentaabono());
    	pago.setCuentacargo(pagoDto.getCuentacargo());
    	pago.setTransaccion(consumerRecord.key().toString());
    	pago.setMonto(pagoDto.getMonto());
        pago.setPagador(pagoDto.getPagador());
    	
    	/*
    	DeudaDto deuda =  new DeudaDto();
    	ClienteDto cliente = new ClienteDto(5, pago.getPagador());
    	ProductoDto producto = new ProductoDto(1, pago.getCausal());
    	
    	deuda.setCliente(cliente);
    	deuda.setProducto(producto);
    	deuda.setMonto(pago.getMonto().doubleValue());
		;
    	try {
    		TransaccionDto tx =   service.registrarPago(deuda);
		
    		 if(tx.getCodigo().equals("0000")) {
    			 logger.info("proceso de resgitro : {} ", tx.getDescripcion() );

             }else {
            	 logger.info("error del proceso de registro : {} ", tx.getDescripcion() );
 			}
    	} catch (AppException e) {
			// TODO Auto-generated catch block
    		 logger.info("proceso de Abono : {} ", e.getMessage() );
			//reversa
		}
		*/
    	try {
    		TransaccionDto tx =   service.guardarPagos(pago);
		
    		 if(tx.getCodigo().equals("0000")) {
    			 logger.info("proceso de resgitro : {} ", tx.getDescripcion() );

             }else {
            	 logger.info("error del proceso de registro : {} ", tx.getDescripcion() );
 			}
    	} catch (AppException e) {
			// TODO Auto-generated catch block
    		 logger.info("proceso de Abono : {} ", e.getMessage() );
			//reversa
		}
    	
    	logger.info("maensaje {}",pago);
		
	}
	

}