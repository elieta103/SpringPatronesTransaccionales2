package com.bsoftgroup.springmscqrsdataadapter.core.dao;



import com.bsoftgroup.springmscqrsdataadapter.configuration.AppException;
import com.bsoftgroup.springmscqrsdataadapter.core.dao.nosql.Pagos;
import com.bsoftgroup.springmscqrsdataadapter.dto.TransaccionDto;

public interface AdapterFacadeInterface {
	
	
	public TransaccionDto guardarPagos(Pagos pago) throws AppException;

}
