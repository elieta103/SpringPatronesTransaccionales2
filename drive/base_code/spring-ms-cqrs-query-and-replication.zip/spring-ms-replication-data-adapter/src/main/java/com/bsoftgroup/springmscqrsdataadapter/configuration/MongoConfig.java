package com.bsoftgroup.springmscqrsdataadapter.configuration;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;

import org.springframework.data.mongodb.config.MongoConfigurationSupport;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;


@EnableMongoRepositories
public class MongoConfig extends MongoConfigurationSupport {
	
	@Value("${mongo.uri}")
    String mongoUri;


	@Override
	protected String getDatabaseName() {
		// TODO Auto-generated method stub
		return null;
	}
	

	@Bean
	public  MongoClient reactiveMongoClient() {
		 return MongoClients.create(mongoUri);
		
	}

}
