package com.bsoftgroup.springmscqrsdataadapter.core.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.bsoftgroup.springmscqrsdataadapter.configuration.AppException;
import com.bsoftgroup.springmscqrsdataadapter.core.dao.nosql.AdpaterNoSQLDaoInterface;
import com.bsoftgroup.springmscqrsdataadapter.core.dao.nosql.Pagos;
import com.bsoftgroup.springmscqrsdataadapter.dto.TransaccionDto;

@Repository
public class AdapterFacade implements AdapterFacadeInterface{
	
	

	
	private final AdpaterNoSQLDaoInterface nosqlDao;
	

	public AdapterFacade(AdpaterNoSQLDaoInterface nosqlDao) {
		this.nosqlDao = nosqlDao;
	}




	@Override
	public TransaccionDto guardarPagos(Pagos pago) throws AppException {
		// TODO Auto-generated method stub
		Pagos pgtmp = nosqlDao.insert(pago);
		TransaccionDto tx= new TransaccionDto();
				tx.setDescripcion("Proceso COnforme");
		        tx.setCodigo("0000");
				
		return tx;
	}

}
