package com.bsoftgroup.springmscqrsdataadapter.core.dao.nosql;

import org.springframework.data.mongodb.repository.MongoRepository;








public interface AdpaterNoSQLDaoInterface extends MongoRepository<Pagos,String>{

	

}
