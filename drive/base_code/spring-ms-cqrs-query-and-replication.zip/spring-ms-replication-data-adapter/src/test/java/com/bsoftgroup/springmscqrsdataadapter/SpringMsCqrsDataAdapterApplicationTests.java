package com.bsoftgroup.springmscqrsdataadapter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringMsCqrsDataAdapterApplicationTests {

	@Test
	void contextLoads() {
	}

}
