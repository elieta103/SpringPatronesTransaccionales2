package com.bsoftgroup.springmscqrscommandcargo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringMsCqrsCommandCargoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringMsCqrsCommandCargoApplication.class, args);
	}

}
