package com.bsoftgroup.springmscqrscommandcargo.core.dao;

import java.math.BigDecimal;

import com.bsoftgroup.springmscqrscommandcargo.configuration.AppException;
import com.bsoftgroup.springmscqrscommandcargo.dto.TransaccionDto;





public interface CargoDaoInterface {
	
	public TransaccionDto generarCargoCuenta(String cuenta, BigDecimal monto,String cliente,String causal,String acreedor,String transaccion) throws AppException;

}