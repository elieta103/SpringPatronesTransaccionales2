package com.bsoftgroup.springmscqrscommandcargo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringMsCqrsCommandCargoApplicationTests {

	@Test
	void contextLoads() {
	}

}
