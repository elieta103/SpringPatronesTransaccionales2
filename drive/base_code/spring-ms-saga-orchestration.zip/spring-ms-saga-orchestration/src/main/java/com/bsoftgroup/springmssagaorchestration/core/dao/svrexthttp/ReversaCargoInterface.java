package com.bsoftgroup.springmssagaorchestration.core.dao.svrexthttp;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.bsoftgroup.springmssagaorchestration.dto.TransaccionDto;

@FeignClient(name="spring-ms-saga-orchestration-reverse-cargo")
public interface ReversaCargoInterface {
	
	@GetMapping(path = "/msreversacargo/cargo/idtransaccion/{transaccion}")
	public TransaccionDto revertirCargo(@PathVariable("transaccion") String trasaccion );

}
