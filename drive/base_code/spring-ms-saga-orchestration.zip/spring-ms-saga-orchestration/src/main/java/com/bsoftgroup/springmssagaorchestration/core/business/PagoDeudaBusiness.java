package com.bsoftgroup.springmssagaorchestration.core.business;

import org.springframework.stereotype.Service;

import com.bsoftgroup.springmssagaorchestration.configuration.AppException;
import com.bsoftgroup.springmssagaorchestration.core.dao.PagoDeudaDaoInterface;
import com.bsoftgroup.springmssagaorchestration.dto.AbonoDto;
import com.bsoftgroup.springmssagaorchestration.dto.CargoDto;
import com.bsoftgroup.springmssagaorchestration.dto.PagoDto;
import com.bsoftgroup.springmssagaorchestration.dto.TransaccionDto;

@Service
public class PagoDeudaBusiness implements PagoDeudaBusinessInterface {
	
	private final PagoDeudaDaoInterface dao;
	
	
	public PagoDeudaBusiness(PagoDeudaDaoInterface dao) {
	this.dao = dao;
	}


	@Override
	public TransaccionDto procesarPago(PagoDto pago) {
		// TODO Auto-generated method stub
		String idTransaccion=null;
		TransaccionDto tx =  new TransaccionDto();
		tx.setCodigo("000");
		tx.setDescripcion("Proceso de Cargo y Abono Conforme");

		try {
			
			//paso01 generar id transaccion
			idTransaccion = dao.getIdTransaccionPago();
		} catch (AppException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			tx.setCodigo("898");
			tx.setDescripcion("Error al generar id de transacción única");
			
			
			return tx; 
		}
		
		
		
		
        CargoDto cargo  =  new CargoDto();
		
		
		cargo.setAcreedor(pago.getAcreedor());
		cargo.setCausal(pago.getCausal());
		cargo.setCliente(pago.getPagador());
		cargo.setCuenta(pago.getCuentacargo());
		cargo.setMonto(pago.getMonto());
		//revertir colocando idtransaccion null
		cargo.setTransaccion(idTransaccion);
		TransaccionDto txcargo =null;
		try {
			//paso02 ejecuta cargo
			txcargo = dao.generarCargoCuenta(cargo);
			
		}catch (Exception e) {
			//llamo reversa cargo
			tx.setCodigo("697");
			tx.setDescripcion("Error al procesar el cargo");
			//llamada a revertir;
			dao.revertirCargo(idTransaccion);
			return tx;
		}
		
		if(txcargo.getCodigo().equals("000")) {
			
			AbonoDto abono = new AbonoDto();
			abono.setCausal(pago.getCausal());
			abono.setCliente(pago.getAcreedor());
			abono.setCuenta(pago.getCuentaabono());
			abono.setMonto(pago.getMonto());
			abono.setPagador(pago.getPagador());
			abono.setTransaccion(idTransaccion);
			
			
			TransaccionDto txabono=null;
			try {
				
				//paso03 ejecuta abono
				txabono = dao.procesarAbono(abono);
				
			}catch (Exception e) {
				//llamo reversa abono
				dao.revertirAbono(idTransaccion);
				//dao.revertirCargo(idTransaccion);
				tx.setCodigo("698");
				tx.setDescripcion("Error al procesar el abono");
				return tx;
			}

			
            if(txabono.getCodigo().equals("000")) {
				
				tx.setCodigo("000");
				tx.setDescripcion("Proceso de Cargo y Abono Conforme");
				tx.setIdgenerado(idTransaccion);
            }else {
				//llamo reversa abono
				dao.revertirAbono(idTransaccion);
				//dao.revertirCargo(idTransaccion);
				tx.setCodigo("698");
				tx.setDescripcion("Error al procesar el abono");
				return tx;
			}
			
		}else {
			//llamo reversa cargo
			tx.setCodigo("697");
			tx.setDescripcion("Error al procesar el cargo");
			dao.revertirCargo(idTransaccion);
			return tx;
		}
		
		return tx;
		
		
	}



	
	
}
