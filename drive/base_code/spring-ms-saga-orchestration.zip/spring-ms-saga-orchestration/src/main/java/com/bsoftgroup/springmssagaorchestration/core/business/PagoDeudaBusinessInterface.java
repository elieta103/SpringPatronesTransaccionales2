package com.bsoftgroup.springmssagaorchestration.core.business;

import com.bsoftgroup.springmssagaorchestration.dto.PagoDto;
import com.bsoftgroup.springmssagaorchestration.dto.TransaccionDto;

public interface PagoDeudaBusinessInterface {
	
	public TransaccionDto procesarPago(PagoDto pago);
}
