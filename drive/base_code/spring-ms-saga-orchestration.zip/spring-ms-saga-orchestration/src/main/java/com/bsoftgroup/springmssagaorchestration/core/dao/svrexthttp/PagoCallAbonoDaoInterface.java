package com.bsoftgroup.springmssagaorchestration.core.dao.svrexthttp;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.bsoftgroup.springmssagaorchestration.dto.AbonoDto;
import com.bsoftgroup.springmssagaorchestration.dto.TransaccionDto;

@FeignClient(name="spring-ms-saga-orchestration-abono")
public interface PagoCallAbonoDaoInterface {
	
	@PostMapping(path = "/msabono/procesar/abono/to/recaudador")
    public TransaccionDto procesarAbono(@RequestBody AbonoDto abono);

}