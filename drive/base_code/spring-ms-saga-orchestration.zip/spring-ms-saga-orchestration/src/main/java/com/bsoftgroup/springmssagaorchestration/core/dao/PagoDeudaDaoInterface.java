package com.bsoftgroup.springmssagaorchestration.core.dao;


import com.bsoftgroup.springmssagaorchestration.configuration.AppException;
import com.bsoftgroup.springmssagaorchestration.dto.AbonoDto;
import com.bsoftgroup.springmssagaorchestration.dto.CargoDto;
import com.bsoftgroup.springmssagaorchestration.dto.TransaccionDto;

public interface PagoDeudaDaoInterface {
	
	public TransaccionDto procesarAbono(AbonoDto abono);
	public TransaccionDto generarCargoCuenta(CargoDto datosCargo);
	public String getIdTransaccionPago() throws AppException;
	public TransaccionDto revertirAbono( String trasaccion );
	public TransaccionDto revertirCargo( String trasaccion );

}
