package com.bsoftgroup.springmssagaorchestration.core.dao.sql;

import com.bsoftgroup.springmssagaorchestration.configuration.AppException;

public interface SQLUtilIterface {
	
	public String getIdTransaccionPago() throws AppException;

}
