package com.bsoftgroup.springmssagaorchestration.core.dao.svrexthttp;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.bsoftgroup.springmssagaorchestration.dto.CargoDto;
import com.bsoftgroup.springmssagaorchestration.dto.TransaccionDto;

@FeignClient(name="spring-ms-saga-orchestration-cargo")
public interface PagoCallCargoDaoInterface {
	
	@PostMapping(path = "/mscargo/procesar/cargo/to/client")
	public TransaccionDto generarCargoCuenta(@RequestBody CargoDto datosCargo);

}