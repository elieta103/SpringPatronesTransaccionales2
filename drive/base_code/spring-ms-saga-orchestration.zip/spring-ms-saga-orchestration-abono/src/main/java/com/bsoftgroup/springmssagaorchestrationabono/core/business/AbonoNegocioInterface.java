package com.bsoftgroup.springmssagaorchestrationabono.core.business;

import java.math.BigDecimal;

import com.bsoftgroup.springmssagaorchestrationabono.configuration.AppException;
import com.bsoftgroup.springmssagaorchestrationabono.dto.TransaccionDto;

public interface AbonoNegocioInterface {
	
	public TransaccionDto procesarAbono(String cuenta,BigDecimal monto, String cliente,String transaccion,String causal,String pagador) throws AppException;

}