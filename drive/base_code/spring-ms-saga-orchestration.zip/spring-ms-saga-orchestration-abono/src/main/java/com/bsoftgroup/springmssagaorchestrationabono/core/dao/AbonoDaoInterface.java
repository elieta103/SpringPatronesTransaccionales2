package com.bsoftgroup.springmssagaorchestrationabono.core.dao;

import java.math.BigDecimal;

import com.bsoftgroup.springmssagaorchestrationabono.configuration.AppException;
import com.bsoftgroup.springmssagaorchestrationabono.dto.TransaccionDto;

public interface AbonoDaoInterface {
	
	public TransaccionDto procesarAbono(String cuenta,BigDecimal monto, String cliente,String transaccion,String causal,String pagador) throws AppException;

}