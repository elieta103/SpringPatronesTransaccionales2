package com.bsoftgroup.springmssagaorchestrationabono.core.dao;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.bsoftgroup.springmssagaorchestrationabono.configuration.AppException;
import com.bsoftgroup.springmssagaorchestrationabono.configuration.ManagementConnection;
import com.bsoftgroup.springmssagaorchestrationabono.dto.TransaccionDto;

@Repository
public class AbonoDao implements AbonoDaoInterface{
	@Autowired
	private ManagementConnection mng;

	@Override
	public TransaccionDto procesarAbono(String cuenta, BigDecimal monto, String cliente, String transaccion,
			String causal, String pagador) throws AppException {
		TransaccionDto tx = new TransaccionDto();
		CallableStatement cstmt = null;
		String idTransaccion;
		
		String SQL = "{? = call esq_ctas_recaudadoras.fn_abono_cuenta(?,?,?,?,?,?)}";
		try {
			cstmt = mng.getConnection().prepareCall(SQL);
			cstmt.registerOutParameter(1, java.sql.Types.VARCHAR);
			cstmt.setString(2, cuenta);
			cstmt.setBigDecimal(3, monto);
			cstmt.setString(4, cliente);
			cstmt.setString(5, transaccion);
			cstmt.setString(6, causal);
			cstmt.setString(7, pagador);
			cstmt.execute();
			idTransaccion = cstmt.getString(1);
			if (idTransaccion.contains("000")) {
				tx.setCodigo("000");
				tx.setDescripcion("Proceso Conforme");
				tx.setIdgenerado(idTransaccion);
			} else {
				tx.setCodigo("111");
				tx.setDescripcion("Error al procesar la transaccion");
			}
			
		} catch (SQLException sqle) {
			throw new AppException(sqle.getMessage());
		} catch (Exception e) {
			throw new AppException(e.getMessage());
		} finally {
			try {
				mng.closeConnection();
				mng.closeCallableStatement(cstmt);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return tx;
	}

}