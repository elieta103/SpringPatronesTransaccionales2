package com.bsoftgroup.springmssagaorchestrationabono.integration;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.bsoftgroup.springmssagaorchestrationabono.configuration.AppException;
import com.bsoftgroup.springmssagaorchestrationabono.core.business.AbonoNegocioInterface;
import com.bsoftgroup.springmssagaorchestrationabono.dto.AbonoDto;
import com.bsoftgroup.springmssagaorchestrationabono.dto.TransaccionDto;

@RestController
public class AbonoRestController {
	
	private Logger logger = LoggerFactory.getLogger(AbonoRestController.class);
	
	@Autowired
	private AbonoNegocioInterface service;
	
	@PostMapping(path = "/procesar/abono/to/recaudador")
    public TransaccionDto procesarAbono(@RequestBody AbonoDto abono) throws AppException{
		
		logger.info("procesarAbono ", "-");
		return service.procesarAbono(abono.getCuenta(), abono.getMonto(), abono.getCliente(), abono.getTransaccion(), abono.getCausal(), abono.getPagador());
	}	

}