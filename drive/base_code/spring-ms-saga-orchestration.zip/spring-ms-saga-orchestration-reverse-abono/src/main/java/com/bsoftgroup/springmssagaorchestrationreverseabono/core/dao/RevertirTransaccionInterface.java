package com.bsoftgroup.springmssagaorchestrationreverseabono.core.dao;

import com.bsoftgroup.springmssagaorchestrationreverseabono.configuration.AppException;
import com.bsoftgroup.springmssagaorchestrationreverseabono.dto.TransaccionDto;

public interface RevertirTransaccionInterface {
	
	public TransaccionDto revertirAbono(String trasaccion )throws AppException;

}
