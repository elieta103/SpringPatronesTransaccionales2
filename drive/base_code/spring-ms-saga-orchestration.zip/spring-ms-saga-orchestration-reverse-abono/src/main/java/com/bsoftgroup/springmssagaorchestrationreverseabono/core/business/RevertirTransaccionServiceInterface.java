package com.bsoftgroup.springmssagaorchestrationreverseabono.core.business;


import com.bsoftgroup.springmssagaorchestrationreverseabono.configuration.AppException;
import com.bsoftgroup.springmssagaorchestrationreverseabono.dto.TransaccionDto;

public interface RevertirTransaccionServiceInterface {
	
	
	public TransaccionDto revertirAbono(String trasaccion ) throws AppException;


}
