package com.bsoftgroup.springmssagaorchestrationreverseabono.integration;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.bsoftgroup.springmssagaorchestrationreverseabono.configuration.AppException;
import com.bsoftgroup.springmssagaorchestrationreverseabono.core.business.RevertirTransaccionServiceInterface;
import com.bsoftgroup.springmssagaorchestrationreverseabono.dto.TransaccionDto;


@RestController
public class ReverseCargoRestController {
	
	private final RevertirTransaccionServiceInterface service;
	
	public ReverseCargoRestController(RevertirTransaccionServiceInterface service) {
		this.service = service;}
	
	
	@GetMapping(path = "/abono/idtransaccion/{transaccion}")
	public TransaccionDto revertirAbono(@PathVariable("transaccion") String trasaccion ) throws AppException {
	
		return service.revertirAbono(trasaccion);
	}

}
