package com.bsoftgroup.springmssagaorchestrationcargo.core.dao;

import java.math.BigDecimal;

import org.springframework.stereotype.Repository;

import com.bsoftgroup.springmssagaorchestrationcargo.configuracion.AppException;
import com.bsoftgroup.springmssagaorchestrationcargo.core.dao.sql.CargoDaoInterface;
import com.bsoftgroup.springmssagaorchestrationcargo.dto.TransaccionDto;

@Repository
public class PagoServiciosFacadeDao implements PagoServiciosFacadeDaoInterface {
	
	private final CargoDaoInterface sql;
	
	

	public PagoServiciosFacadeDao(CargoDaoInterface sql) {
		this.sql = sql;
	}



	@Override
	public TransaccionDto generarCargoCuenta(String cuenta, BigDecimal monto, String cliente, String causal,
			String acreedor, String transaccion) throws AppException {
		// TODO Auto-generated method stub
		return this.sql.generarCargoCuenta(cuenta, monto, cliente, causal, acreedor, transaccion);
	}

}
