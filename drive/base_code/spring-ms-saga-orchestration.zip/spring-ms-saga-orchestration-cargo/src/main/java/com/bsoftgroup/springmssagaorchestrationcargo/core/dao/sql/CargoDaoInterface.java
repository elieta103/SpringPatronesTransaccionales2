package com.bsoftgroup.springmssagaorchestrationcargo.core.dao.sql;

import java.math.BigDecimal;

import com.bsoftgroup.springmssagaorchestrationcargo.configuracion.AppException;
import com.bsoftgroup.springmssagaorchestrationcargo.dto.TransaccionDto;



public interface CargoDaoInterface {
	
	public TransaccionDto generarCargoCuenta(String cuenta, BigDecimal monto,String cliente,String causal,String acreedor,String transaccion) throws AppException;

}