package com.bsoftgroup.springmssagaorchestrationcargo.core.business;

import java.math.BigDecimal;

import com.bsoftgroup.springmssagaorchestrationcargo.configuracion.AppException;
import com.bsoftgroup.springmssagaorchestrationcargo.dto.TransaccionDto;



public interface CargoNegocioInterface {
	
	public TransaccionDto generarCargoCuenta(String cuenta, BigDecimal monto,String cliente,String causal,String acreedor,String transaccion) throws AppException;

}