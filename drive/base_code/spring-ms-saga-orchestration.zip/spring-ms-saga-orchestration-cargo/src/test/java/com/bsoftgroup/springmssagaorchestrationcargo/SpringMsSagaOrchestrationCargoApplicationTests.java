package com.bsoftgroup.springmssagaorchestrationcargo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringMsSagaOrchestrationCargoApplicationTests {

	@Test
	void contextLoads() {
	}

}
