package com.bsoftgroup.springmssagaorchestrationreversecargo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringMsSagaOrchestrationReverseCargoApplicationTests {

	@Test
	void contextLoads() {
	}

}
