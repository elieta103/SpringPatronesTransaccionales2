package com.bsoftgroup.springmssagaorchestrationreversecargo.core.dao;

import com.bsoftgroup.springmssagaorchestrationreversecargo.configuration.AppException;
import com.bsoftgroup.springmssagaorchestrationreversecargo.dto.TransaccionDto;

public interface RevertirTransaccionInterface {
	
	public TransaccionDto revertirCargo(String trasaccion )throws AppException;
	

}
