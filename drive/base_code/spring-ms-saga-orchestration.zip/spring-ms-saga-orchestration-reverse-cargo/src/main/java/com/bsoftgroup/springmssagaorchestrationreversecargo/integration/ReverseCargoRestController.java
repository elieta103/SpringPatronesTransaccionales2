package com.bsoftgroup.springmssagaorchestrationreversecargo.integration;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.bsoftgroup.springmssagaorchestrationreversecargo.configuration.AppException;
import com.bsoftgroup.springmssagaorchestrationreversecargo.core.business.RevertirTransaccionServiceInterface;
import com.bsoftgroup.springmssagaorchestrationreversecargo.dto.TransaccionDto;


@RestController
public class ReverseCargoRestController {
	
	private final RevertirTransaccionServiceInterface service;
	
	public ReverseCargoRestController(RevertirTransaccionServiceInterface service) {
		this.service = service;}
	
	@GetMapping(path = "/cargo/idtransaccion/{transaccion}")
	public TransaccionDto revertirCargo(@PathVariable("transaccion") String trasaccion ) throws AppException {
	
		return service.revertirCargo(trasaccion);
	}
	
}
