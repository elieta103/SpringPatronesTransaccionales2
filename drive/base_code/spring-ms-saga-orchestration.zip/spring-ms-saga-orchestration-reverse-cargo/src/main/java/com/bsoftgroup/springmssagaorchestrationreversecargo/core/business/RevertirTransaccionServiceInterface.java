package com.bsoftgroup.springmssagaorchestrationreversecargo.core.business;

import com.bsoftgroup.springmssagaorchestrationreversecargo.configuration.AppException;
import com.bsoftgroup.springmssagaorchestrationreversecargo.dto.TransaccionDto;

public interface RevertirTransaccionServiceInterface {
	
	public TransaccionDto revertirCargo(String trasaccion ) throws AppException;


}
