package com.bsoftgroup.springmssagaorchestrationreversecargo.configuration;

import javax.sql.DataSource;

import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

import com.zaxxer.hikari.HikariDataSource;

@Configuration
public class DataSourceConfig {

	@Bean(name="propertiespostgres")
	@Primary
    @ConfigurationProperties("spring.datasource")
	public DataSourceProperties dataSourceProperties() {
		 return new DataSourceProperties();
		
	}
	
	@Bean(name="dataSource")
	@Primary
    @ConfigurationProperties(prefix="spring.datasource.configuration")
    public DataSource dataSource() {
		
        return dataSourceProperties().initializeDataSourceBuilder().type(HikariDataSource.class).build();
    }
	
	/*
	
	@Bean(name="propertiespostgres2")
    @ConfigurationProperties("spring.datasourcepostgres")
	public DataSourceProperties dataSourceProperties2() {
		 return new DataSourceProperties();
		
	}
	
	@Bean(name="dataSource2")
    @ConfigurationProperties(prefix="spring.datasourcepostgres.configuration")
    public DataSource dataSource2() {
		
        return dataSourceProperties2().initializeDataSourceBuilder().type(HikariDataSource.class).build();
    }
    */
	
	
	

}
