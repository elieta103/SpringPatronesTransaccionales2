package com.bsoftgroup.springmssagaorchestrationreversecargo.core.business;

import org.springframework.stereotype.Service;

import com.bsoftgroup.springmssagaorchestrationreversecargo.configuration.AppException;
import com.bsoftgroup.springmssagaorchestrationreversecargo.core.dao.RevertirTransaccionInterface;
import com.bsoftgroup.springmssagaorchestrationreversecargo.dto.TransaccionDto;


@Service
public class RevertirTransaccionService implements RevertirTransaccionServiceInterface {
	
	
	private final RevertirTransaccionInterface dao;
	
	public  RevertirTransaccionService(RevertirTransaccionInterface dao) {
		this.dao = dao;}

	@Override
	public TransaccionDto revertirCargo(String trasaccion) throws AppException{
		// TODO Auto-generated method stub
		return dao.revertirCargo(trasaccion);
	}


}
