package com.bsoftgroup.springmssagachoreography.core.dao;

import com.bsoftgroup.springmssagachoreography.configuration.AppException;
import com.bsoftgroup.springmssagachoreography.dto.PagoDto;
import com.fasterxml.jackson.core.JsonProcessingException;

public interface PagoDeudaDaoInterface {
	public String getIdTransaccionPago() throws AppException;
	 public void eventoPago(PagoDto pago, Integer transaccion) throws JsonProcessingException;
	 public String eventoPagoReply(PagoDto pago, Integer transaccion) throws Exception;

}
