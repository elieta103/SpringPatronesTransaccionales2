package com.bsoftgroup.springmssagachoreography.core.dao;

import org.springframework.stereotype.Component;

import com.bsoftgroup.springmssagachoreography.configuration.AppException;
import com.bsoftgroup.springmssagachoreography.core.dao.kafka.PublicadorInterface;
import com.bsoftgroup.springmssagachoreography.core.dao.sql.SQLUtilIterface;
import com.bsoftgroup.springmssagachoreography.dto.PagoDto;
import com.fasterxml.jackson.core.JsonProcessingException;

@Component
public class PagoDeudaDao implements PagoDeudaDaoInterface {
	
	private final SQLUtilIterface sql;
	
	private final PublicadorInterface kafka;
	
	


	public PagoDeudaDao(SQLUtilIterface sql, PublicadorInterface kafka) {
		this.sql = sql;
		this.kafka = kafka;

		
	}




	@Override
	public String getIdTransaccionPago() throws AppException {
		// TODO Auto-generated method stub
		return sql.getIdTransaccionPago();
	}




	@Override
	public void eventoPago(PagoDto pago, Integer transaccion) throws JsonProcessingException {
		// TODO Auto-generated method stub
		
		    kafka.eventoPago(pago, transaccion);
		
	}




	@Override
	public String eventoPagoReply(PagoDto pago, Integer transaccion) throws Exception {
		// TODO Auto-generated method stub
		 return kafka.kafkaRequestReply(pago, transaccion);
	}




	
}
