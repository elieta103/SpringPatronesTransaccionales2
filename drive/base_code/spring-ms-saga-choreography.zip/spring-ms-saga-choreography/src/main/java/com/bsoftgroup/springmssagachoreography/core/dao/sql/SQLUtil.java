package com.bsoftgroup.springmssagachoreography.core.dao.sql;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.bsoftgroup.springmssagachoreography.configuration.AppException;
import com.bsoftgroup.springmssagachoreography.configuration.ManagementConnection;




@Repository
public class SQLUtil implements SQLUtilIterface{
	
	@Autowired
	private ManagementConnection mng;

	@Override
	public String getIdTransaccionPago() throws AppException {
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String transaccion=null;
		Connection con=null;
		try {
			con = mng.getConnection();
		} catch (Exception e) {
			throw new AppException(e.getMessage());
		}
	try {
		String SQL = "select nextval('SEQ_PAGO_ID') as id;";
		pstmt = con.prepareStatement(SQL);
		rs = pstmt.executeQuery();
		
		while (rs.next()) {
			transaccion = String.valueOf(rs.getInt("id"));
					//new Integer(rs.getInt("id")).toString();
			
		}
	} catch (Exception e) {
		throw new AppException(e.getMessage());
	} finally {
		try {
			mng.closeResources(con, rs, null, null, pstmt);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
			
				
		return transaccion;
	}

}
