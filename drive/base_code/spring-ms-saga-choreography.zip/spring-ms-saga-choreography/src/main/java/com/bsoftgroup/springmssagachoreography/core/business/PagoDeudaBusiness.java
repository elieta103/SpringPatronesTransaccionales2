package com.bsoftgroup.springmssagachoreography.core.business;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bsoftgroup.springmssagachoreography.configuration.AppException;
import com.bsoftgroup.springmssagachoreography.core.dao.PagoDeudaDaoInterface;
import com.bsoftgroup.springmssagachoreography.dto.PagoDto;
import com.bsoftgroup.springmssagachoreography.dto.TransaccionDto;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;



@Service
public class PagoDeudaBusiness implements PagoDeudaBusinessInterface {
	
	private final PagoDeudaDaoInterface dao;
	
	@Autowired
    ObjectMapper objectMapper;
	
	Logger log = LoggerFactory.getLogger(getClass());
	
	public PagoDeudaBusiness(PagoDeudaDaoInterface dao) {
	this.dao = dao;
	}


	@Override
	public TransaccionDto procesarPago(PagoDto pago) {
		// TODO Auto-generated method stub
		String idTransaccion=null;
		TransaccionDto tx =  new TransaccionDto();
		tx.setCodigo("000");
		tx.setDescripcion("Cargo y Abono en proceso");

		try {
			
			//paso01 generar id transaccion
			idTransaccion = dao.getIdTransaccionPago();
			
		} catch (AppException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			tx.setCodigo("898");
			tx.setDescripcion("Error al generar id de transacción única");
			
			
			return tx; 
		}
		
		try {
			

			
			dao.eventoPago(pago,Integer.valueOf(idTransaccion));
			
			tx.setIdgenerado(idTransaccion);
			
			
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			tx.setCodigo("899");
			tx.setDescripcion("Error al procesar transaccion de cargo y abono");
		}
		
		return tx;
       
		
		
	}


	@Override
	public TransaccionDto procesarPagoReply(PagoDto pago) {
		// TODO Auto-generated method stub
		String idTransaccion=null;
		TransaccionDto tx =  new TransaccionDto();
		//tx.setCodigo("000");
		//tx.setDescripcion("Proceso de Cargo y Abono Conforme");

		try {
			
			//paso01 generar id transaccion
			idTransaccion = dao.getIdTransaccionPago();
			
		} catch (AppException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			tx.setCodigo("898");
			tx.setDescripcion("Error al generar id de transacción única");
			
			
			return tx; 
		}
		
		try {
			

			
			String sendReply = dao.eventoPagoReply(pago,Integer.valueOf(idTransaccion));
			tx = objectMapper.readValue(sendReply, TransaccionDto.class);
			log.info("resultado del proceso reply== "+ tx.getCodigo());
			//tx.setIdgenerado(idTransaccion);
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			tx.setCodigo("899");
			tx.setDescripcion("Error al procesar transaccion de cargo y abono");
		}
		
		return tx;
	}



	
	
}
