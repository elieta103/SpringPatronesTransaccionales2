package com.bsoftgroup.springmssagachoreography.core.dao.kafka;

import com.bsoftgroup.springmssagachoreography.dto.PagoDto;
import com.fasterxml.jackson.core.JsonProcessingException;

public interface PublicadorInterface {
	
	 public void eventoPago(PagoDto pago, Integer transaccion) throws JsonProcessingException;
	 public String kafkaRequestReply(PagoDto pago, Integer transaccion) throws Exception;
	 

}
