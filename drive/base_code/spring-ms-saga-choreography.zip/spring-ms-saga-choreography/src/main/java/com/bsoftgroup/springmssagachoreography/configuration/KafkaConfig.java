package com.bsoftgroup.springmssagachoreography.configuration;



import org.apache.kafka.clients.admin.NewTopic;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.config.TopicBuilder;
import org.springframework.kafka.core.ProducerFactory;
import org.springframework.kafka.listener.ConcurrentMessageListenerContainer;
import org.springframework.kafka.requestreply.ReplyingKafkaTemplate;

@Configuration
public class KafkaConfig {
	
    @Value("${myproject.reply-topics}")
    private String REPLY_TOPICS;
    
    @Value("${myproject.consumer-group}")
    private String CONSUMER_GROUPS;

	
	@Bean
    public NewTopic libraryEvents(){
        return TopicBuilder.name(REPLY_TOPICS)
                .partitions(1)
                .replicas(1)
                .build();
    }
	

    @Bean //register and configure replying kafka template
    public ReplyingKafkaTemplate<Integer, String, String> replyingTemplate(ProducerFactory<Integer, String> pf,ConcurrentMessageListenerContainer<Integer, String> repliesContainer) {
        return new ReplyingKafkaTemplate<>(pf, repliesContainer);
    }

    @Bean //register ConcurrentMessageListenerContainer bean
    public ConcurrentMessageListenerContainer<Integer, String> repliesContainer(ConcurrentKafkaListenerContainerFactory<Integer, String> containerFactory) {
        ConcurrentMessageListenerContainer<Integer, String> repliesContainer = containerFactory.createContainer(REPLY_TOPICS);
        repliesContainer.getContainerProperties().setGroupId(CONSUMER_GROUPS);
        repliesContainer.setAutoStartup(false);
        return repliesContainer;
    }

}