package com.bsoftgroup.springmssagachoreography.core.business;

import com.bsoftgroup.springmssagachoreography.dto.PagoDto;
import com.bsoftgroup.springmssagachoreography.dto.TransaccionDto;

public interface PagoDeudaBusinessInterface {
	
	public TransaccionDto procesarPago(PagoDto pago);
	public TransaccionDto procesarPagoReply(PagoDto pago);
}
