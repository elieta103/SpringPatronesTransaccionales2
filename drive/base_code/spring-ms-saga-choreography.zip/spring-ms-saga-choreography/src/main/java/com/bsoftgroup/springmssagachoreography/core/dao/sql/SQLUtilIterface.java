package com.bsoftgroup.springmssagachoreography.core.dao.sql;

import com.bsoftgroup.springmssagachoreography.configuration.AppException;

public interface SQLUtilIterface {
	
	public String getIdTransaccionPago() throws AppException;

}
