package com.bsoftgroup.springmssagachoreography.integration;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.bsoftgroup.springmssagachoreography.core.business.PagoDeudaBusinessInterface;
import com.bsoftgroup.springmssagachoreography.dto.PagoDto;
import com.bsoftgroup.springmssagachoreography.dto.TransaccionDto;



@RestController
public class PagoDeudaRestController {
	
	private final PagoDeudaBusinessInterface service;
	
	
	public PagoDeudaRestController(PagoDeudaBusinessInterface service) {
		this.service = service;}
	

	
	@PostMapping(path = "/procesar/cargo/abono")
	public TransaccionDto generarCargoCuenta(@RequestBody PagoDto pago) {
		
		return service.procesarPago(pago);
		
	}

	@PostMapping(path = "/procesar/reply/cargo/abono")
	public TransaccionDto generarCargoCuentaReply(@RequestBody PagoDto pago) {
		
		return service.procesarPagoReply(pago);
		
	}
}