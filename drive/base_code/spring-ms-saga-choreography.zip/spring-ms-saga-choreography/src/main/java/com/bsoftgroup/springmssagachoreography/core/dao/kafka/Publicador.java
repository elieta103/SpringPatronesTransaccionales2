package com.bsoftgroup.springmssagachoreography.core.dao.kafka;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.requestreply.ReplyingKafkaTemplate;
import org.springframework.kafka.requestreply.RequestReplyFuture;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Component;
import org.springframework.util.concurrent.ListenableFuture;
import org.springframework.util.concurrent.ListenableFutureCallback;

import com.bsoftgroup.springmssagachoreography.dto.PagoDto;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class Publicador implements PublicadorInterface {
	
	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
    KafkaTemplate<Integer,String> kafkaTemplate;
	
	
	
    @Autowired
    private ReplyingKafkaTemplate<Integer, String, String> replytemplate;
    
    
    @Value("${spring.kafka.template.default-topic}")
    private String SEND_TOPICS;
	
	 //String topic = "pago-events";
	
	 //@Autowired
	// private ReplyingKafkaTemplate<Integer, String, String> template;
	 
	 @Autowired
	 ObjectMapper objectMapper;

	@Override
	 public void eventoPago(PagoDto pago, Integer transaccion) throws JsonProcessingException {
		 Integer key=transaccion;
		 String value=objectMapper.writeValueAsString(pago);
		 
		ListenableFuture<SendResult<Integer,String>> listenableFuture =  kafkaTemplate.send(this.SEND_TOPICS,key, value);
		listenableFuture.addCallback(new ListenableFutureCallback<SendResult<Integer, String>>() {
	            @Override
	            public void onFailure(Throwable ex) {
	                handleFailure(key, value, ex);//
	                //
	            }

	            @Override
	            public void onSuccess(SendResult<Integer, String> result) {
	                handleSuccess(key, value, result);
	            }
	        });

	 }
	 
	 private void handleFailure(Integer key, String value, Throwable ex) {
		 logger.error("Error Sending the Message and the exception is {}", ex.getMessage());
	        try {
	            throw ex;
	        } catch (Throwable throwable) {
	        	logger.error("Error in OnFailure: {}", throwable.getMessage());
	        }


	    }

	    private void handleSuccess(Integer key, String value, SendResult<Integer, String> result) {
	    	logger.info("Message Sent SuccessFully for the key : {} and the value is {} , partition is {}", key, value, result.getRecordMetadata().partition());
	    }

		@Override
		public String kafkaRequestReply(PagoDto pago, Integer transaccion) throws Exception {
			// TODO Auto-generated method stub
			
			 Integer key=transaccion;
			 String value=objectMapper.writeValueAsString(pago);
			 
			//logger.info("SEND_TOPICS=",this.SEND_TOPICS);
	        ProducerRecord<Integer, String> record = new ProducerRecord<Integer, String>(this.SEND_TOPICS,key, value);
	        RequestReplyFuture<Integer, String, String> replyFuture = replytemplate.sendAndReceive(record);
	        SendResult<Integer, String> sendResult = replyFuture.getSendFuture().get(10, TimeUnit.SECONDS);//si obtiene un resultado todo es ok
	        logger.info("PASO=",sendResult.getRecordMetadata());
	        ConsumerRecord<Integer, String> consumerRecord = replyFuture.get(20, TimeUnit.SECONDS);
	        logger.info("code=+",consumerRecord.value());
	        return consumerRecord.value();
		}


	 
	
	 
}