package com.bsoftgroup.springmssagachoreography;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringMsSagaChoreographyApplicationTests {

	@Test
	void contextLoads() {
	}

}
