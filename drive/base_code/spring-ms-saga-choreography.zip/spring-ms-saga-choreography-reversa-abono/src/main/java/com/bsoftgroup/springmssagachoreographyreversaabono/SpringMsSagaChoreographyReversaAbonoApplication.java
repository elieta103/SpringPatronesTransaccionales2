package com.bsoftgroup.springmssagachoreographyreversaabono;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

@SpringBootApplication
@EnableDiscoveryClient
public class SpringMsSagaChoreographyReversaAbonoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringMsSagaChoreographyReversaAbonoApplication.class, args);
	}

}
