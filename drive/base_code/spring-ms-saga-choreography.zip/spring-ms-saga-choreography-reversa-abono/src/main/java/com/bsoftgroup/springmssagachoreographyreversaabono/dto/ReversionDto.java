package com.bsoftgroup.springmssagachoreographyreversaabono.dto;

public class ReversionDto {
	
	private String causal;
	private String transaccion;
	public String getCausal() {
		return causal;
	}
	public void setCausal(String causal) {
		this.causal = causal;
	}
	public String getTransaccion() {
		return transaccion;
	}
	public void setTransaccion(String transaccion) {
		this.transaccion = transaccion;
	} 

}
