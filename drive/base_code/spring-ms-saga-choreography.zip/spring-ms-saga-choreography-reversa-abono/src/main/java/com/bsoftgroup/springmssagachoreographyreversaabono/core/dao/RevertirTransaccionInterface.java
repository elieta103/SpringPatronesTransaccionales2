package com.bsoftgroup.springmssagachoreographyreversaabono.core.dao;

import com.bsoftgroup.springmssagachoreographyreversaabono.configuration.AppException;
import com.bsoftgroup.springmssagachoreographyreversaabono.dto.TransaccionDto;

public interface RevertirTransaccionInterface {
	

	public TransaccionDto revertirAbono(String trasaccion )throws AppException;

}
