package com.bsoftgroup.springmssagachoreographyreversaabono.core.business;

import com.bsoftgroup.springmssagachoreographyreversaabono.configuration.AppException;
import com.bsoftgroup.springmssagachoreographyreversaabono.dto.TransaccionDto;

public interface RevertirTransaccionServiceInterface {
	
	
	public TransaccionDto revertirAbono(String trasaccion ) throws AppException;


}
