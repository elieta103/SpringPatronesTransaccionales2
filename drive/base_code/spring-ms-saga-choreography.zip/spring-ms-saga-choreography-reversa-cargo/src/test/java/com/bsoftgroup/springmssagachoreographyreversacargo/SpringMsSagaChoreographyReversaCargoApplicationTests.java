package com.bsoftgroup.springmssagachoreographyreversacargo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringMsSagaChoreographyReversaCargoApplicationTests {

	@Test
	void contextLoads() {
	}

}
