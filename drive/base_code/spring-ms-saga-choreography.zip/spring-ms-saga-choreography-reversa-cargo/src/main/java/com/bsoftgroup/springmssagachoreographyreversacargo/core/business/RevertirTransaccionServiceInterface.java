package com.bsoftgroup.springmssagachoreographyreversacargo.core.business;

import com.bsoftgroup.springmssagachoreographyreversacargo.configuration.AppException;
import com.bsoftgroup.springmssagachoreographyreversacargo.dto.TransaccionDto;

public interface RevertirTransaccionServiceInterface {
	
	public TransaccionDto revertirCargo(String trasaccion ) throws AppException;



}
