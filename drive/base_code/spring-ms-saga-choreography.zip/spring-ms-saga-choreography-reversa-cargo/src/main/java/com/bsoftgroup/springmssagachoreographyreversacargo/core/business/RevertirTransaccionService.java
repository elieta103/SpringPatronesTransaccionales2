package com.bsoftgroup.springmssagachoreographyreversacargo.core.business;

import org.springframework.stereotype.Service;

import com.bsoftgroup.springmssagachoreographyreversacargo.configuration.AppException;
import com.bsoftgroup.springmssagachoreographyreversacargo.core.dao.RevertirTransaccionInterface;
import com.bsoftgroup.springmssagachoreographyreversacargo.dto.TransaccionDto;




@Service
public class RevertirTransaccionService implements RevertirTransaccionServiceInterface {
	
	
	private final RevertirTransaccionInterface dao;
	
	public  RevertirTransaccionService(RevertirTransaccionInterface dao) {
		this.dao = dao;
		
	}


	@Override
	public TransaccionDto revertirCargo(String trasaccion) throws AppException{
		// TODO Auto-generated method stub
		return dao.revertirCargo(trasaccion);
	}


}
