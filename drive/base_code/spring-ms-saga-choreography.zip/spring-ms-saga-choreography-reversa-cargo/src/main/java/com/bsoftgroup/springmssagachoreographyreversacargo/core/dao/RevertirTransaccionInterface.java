package com.bsoftgroup.springmssagachoreographyreversacargo.core.dao;

import com.bsoftgroup.springmssagachoreographyreversacargo.configuration.AppException;
import com.bsoftgroup.springmssagachoreographyreversacargo.dto.TransaccionDto;

public interface RevertirTransaccionInterface {
	
	public TransaccionDto revertirCargo(String trasaccion )throws AppException;
	

}
