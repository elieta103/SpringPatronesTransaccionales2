package com.bsoftgroup.springmssagachoreographyreversacargo.integration;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

import com.bsoftgroup.springmssagachoreographyreversacargo.configuration.AppException;
import com.bsoftgroup.springmssagachoreographyreversacargo.core.business.RevertirTransaccionServiceInterface;
import com.bsoftgroup.springmssagachoreographyreversacargo.dto.ReversionDto;
import com.bsoftgroup.springmssagachoreographyreversacargo.dto.TransaccionDto;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class Consumer {
	Logger logger = LoggerFactory.getLogger(Consumer.class);
	
	@Autowired
    ObjectMapper objectMapper;
	
	@Autowired
	private RevertirTransaccionServiceInterface service;
	
	//@KafkaListener(topics = {"pago-events-reversa-cargo"})
	@KafkaListener(groupId="${spring.kafka.consumer.group-id}", topics = "${spring.kafka.template.default-topic}")
	public void onMessage(ConsumerRecord<Integer,String> consumerRecord) throws JsonProcessingException {
		logger.info("ConsumerRecord : {} ", consumerRecord );
        //libraryEventsService.processLibraryEvent(consumerRecord);
		TransaccionDto tx=null;
    	ReversionDto reversion = objectMapper.readValue(consumerRecord.value(), ReversionDto.class);
    	
		
    	try {

		
                tx= service.revertirCargo(reversion.getTransaccion());
	    		
	    		logger.info("reversa de cargo : {} ", tx.getDescripcion() );


    		
    	} catch (AppException e) {
			// TODO Auto-generated catch block
    		 logger.info("proceso de Abono : {} ", e.getMessage() );
			//reversa
		}
    	
    	logger.info("maensaje {}","proceso de reversion conforme");
		
	}

}