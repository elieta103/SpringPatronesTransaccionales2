package com.bsoftgroup.springmssagachoreographyreversacargo.core.dao;

import java.sql.CallableStatement;
import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.bsoftgroup.springmssagachoreographyreversacargo.configuration.AppException;
import com.bsoftgroup.springmssagachoreographyreversacargo.configuration.ManagementConnection;
import com.bsoftgroup.springmssagachoreographyreversacargo.dto.TransaccionDto;




@Repository
public class RevertirTransaccion implements RevertirTransaccionInterface {
	
	@Autowired
	private ManagementConnection mng;

	@Override
	public TransaccionDto revertirCargo(String transaccion) throws AppException {
		TransaccionDto tx = new TransaccionDto();
		CallableStatement cstmt = null;
		String idTransaccion;
		String metodo = "";

		String SQL = "{? = call esq_ctas_clientes.fn_reversa_cargo_cuenta(?)}";
		try {
			cstmt = mng.getConnection().prepareCall(SQL);
			cstmt.registerOutParameter(1, java.sql.Types.VARCHAR);
			cstmt.setString(2, transaccion);
			cstmt.execute();
			String[] info = cstmt.getString(1).split("-");
			idTransaccion=info[1];
			if (idTransaccion!=null) {
				tx.setCodigo("000");
				tx.setDescripcion("Proceso Conforme");
			} else {
				tx.setCodigo("111");
				tx.setDescripcion("Error al procesar la transaccion");
			}

		} catch (SQLException sqle) {
			throw new AppException(sqle.getMessage());
		} catch (Exception e) {
			throw new AppException(e.getMessage());
		} finally {
				try {
					mng.closeConnection();
					mng.closeCallableStatement(cstmt);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

		}
		return tx;
	}


	
}
