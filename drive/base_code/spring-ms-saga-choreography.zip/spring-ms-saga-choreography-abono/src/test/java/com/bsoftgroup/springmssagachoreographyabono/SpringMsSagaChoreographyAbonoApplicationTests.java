package com.bsoftgroup.springmssagachoreographyabono;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringMsSagaChoreographyAbonoApplicationTests {

	@Test
	void contextLoads() {
	}

}
