package com.bsoftgroup.springmssagachoreographyabono.core.dao;

import java.math.BigDecimal;

import org.springframework.stereotype.Component;

import com.bsoftgroup.springmssagachoreographyabono.configuration.AppException;
import com.bsoftgroup.springmssagachoreographyabono.core.dao.kafka.PublicadorInterface;
import com.bsoftgroup.springmssagachoreographyabono.core.dao.sql.AbonoDaoSQLInterface;
import com.bsoftgroup.springmssagachoreographyabono.dto.ReversionDto;
import com.bsoftgroup.springmssagachoreographyabono.dto.TransaccionDto;
import com.fasterxml.jackson.core.JsonProcessingException;

@Component
public class AbonoFacadeDao implements AbonoFacadeDaoInterface {
	
	
	private final PublicadorInterface kafka;
	private final AbonoDaoSQLInterface sql;
	
	

	public AbonoFacadeDao(AbonoDaoSQLInterface sql, PublicadorInterface kafka) {
		this.kafka = kafka;
		this.sql = sql;
		
	}

	@Override
	public void revertirAbono(ReversionDto reversion, Integer transaccion) throws JsonProcessingException {
		// TODO Auto-generated method stub
		kafka.revertirAbono(reversion, transaccion);
	}

	@Override
	public TransaccionDto procesarAbono(String cuenta, BigDecimal monto, String cliente, String transaccion,
			String causal, String pagador) throws AppException {
		// TODO Auto-generated method stub
		return sql.procesarAbono(cuenta, monto, cliente, transaccion, causal, pagador);
	}

}
