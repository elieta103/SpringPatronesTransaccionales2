package com.bsoftgroup.springmssagachoreographyabono.core.business;

import java.math.BigDecimal;

import com.bsoftgroup.springmssagachoreographyabono.configuration.AppException;



public interface AbonoNegocioInterface {
	
	public com.bsoftgroup.springmssagachoreographyabono.dto.TransaccionDto procesarAbono(String cuenta,BigDecimal monto, String cliente,String transaccion,String causal,String pagador) throws AppException;

}