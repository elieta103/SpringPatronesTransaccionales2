package com.bsoftgroup.springmssagachoreographyabono.core.dao.sql;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.bsoftgroup.springmssagachoreographyabono.configuration.AppException;
import com.bsoftgroup.springmssagachoreographyabono.configuration.ManagementConnection;
import com.bsoftgroup.springmssagachoreographyabono.dto.TransaccionDto;



@Repository
public class AbonoSQLDao implements AbonoDaoSQLInterface{
	@Autowired
	private ManagementConnection mng;

	@Override
	public TransaccionDto procesarAbono(String cuenta, BigDecimal monto, String cliente, String transaccion,
			String causal, String pagador) throws AppException {
		TransaccionDto tx = new TransaccionDto();
		CallableStatement cstmt = null;
		String idTransaccion;
		
		String SQL = "{? = call esq_ctas_recaudadoras.fn_abono_cuenta(?,?,?,?,?,?)}";
		try {
			cstmt = mng.getConnection().prepareCall(SQL);
			cstmt.registerOutParameter(1, java.sql.Types.VARCHAR);
			cstmt.setString(2, cuenta);
			cstmt.setBigDecimal(3, monto);
			cstmt.setString(4, cliente);
			cstmt.setString(5, transaccion);
			cstmt.setString(6, causal);
			cstmt.setString(7, pagador);
			cstmt.execute();
			idTransaccion = cstmt.getString(1);
			if (idTransaccion.contains("000")) {
				tx.setCodigo("000");
				tx.setDescripcion("Proceso Abono Conforme");
				tx.setIdgenerado(transaccion);
			} else {
				tx.setCodigo("111");
				tx.setDescripcion("Error al procesar la transaccion abono");
			}
			
		} catch (SQLException sqle) {
			throw new AppException(sqle.getMessage());
		} catch (Exception e) {
			throw new AppException(e.getMessage());
		} finally {
			try {
				mng.closeConnection();
				mng.closeCallableStatement(cstmt);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return tx;
	}

}