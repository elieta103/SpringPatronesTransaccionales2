package com.bsoftgroup.springmssagachoreographyabono.core.business;

import java.math.BigDecimal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bsoftgroup.springmssagachoreographyabono.configuration.AppException;
import com.bsoftgroup.springmssagachoreographyabono.core.dao.AbonoFacadeDaoInterface;
import com.bsoftgroup.springmssagachoreographyabono.core.dao.sql.AbonoDaoSQLInterface;
import com.bsoftgroup.springmssagachoreographyabono.dto.ReversionDto;
import com.bsoftgroup.springmssagachoreographyabono.dto.TransaccionDto;
import com.fasterxml.jackson.core.JsonProcessingException;



@Service
public class AbonoBusiness implements AbonoNegocioInterface{
	
	@Autowired
	private AbonoFacadeDaoInterface dao;

	@Override
	public TransaccionDto procesarAbono(String cuenta, BigDecimal monto, String cliente, String transaccion,
			String causal, String pagador) throws AppException  {
		// TODO Auto-generated method stub
		TransaccionDto trx = new TransaccionDto();

		try {
			trx= dao.procesarAbono(cuenta, monto, cliente, transaccion, causal, pagador);
		
		    if(!trx.getCodigo().equals("000")) {
				ReversionDto reversa = new ReversionDto();
				reversa.setTransaccion(transaccion);
				reversa.setCausal("ABONO");
				try {
					dao.revertirAbono(reversa, Integer.valueOf(transaccion));
				} catch (JsonProcessingException | NumberFormatException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				trx.setCodigo("787");
				trx.setDescripcion("Revirtiendo el Abono");
				
		    }
		} catch (AppException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();

			throw new AppException(e.getMessage());
		}
		return trx;
	}

}