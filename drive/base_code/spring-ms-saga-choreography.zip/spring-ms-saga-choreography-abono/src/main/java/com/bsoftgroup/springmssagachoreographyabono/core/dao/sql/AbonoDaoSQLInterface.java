package com.bsoftgroup.springmssagachoreographyabono.core.dao.sql;

import java.math.BigDecimal;

import com.bsoftgroup.springmssagachoreographyabono.configuration.AppException;
import com.bsoftgroup.springmssagachoreographyabono.dto.TransaccionDto;



public interface AbonoDaoSQLInterface {
	
	public TransaccionDto procesarAbono(String cuenta,BigDecimal monto, String cliente,String transaccion,String causal,String pagador) throws AppException;

}