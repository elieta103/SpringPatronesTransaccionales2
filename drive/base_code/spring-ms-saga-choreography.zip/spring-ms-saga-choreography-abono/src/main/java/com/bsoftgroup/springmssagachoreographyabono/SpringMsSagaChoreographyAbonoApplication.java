package com.bsoftgroup.springmssagachoreographyabono;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringMsSagaChoreographyAbonoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringMsSagaChoreographyAbonoApplication.class, args);
	}

}
