package com.bsoftgroup.springmssagachoreographyabono.integration;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.Message;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.stereotype.Component;

import com.bsoftgroup.springmssagachoreographyabono.configuration.AppException;
import com.bsoftgroup.springmssagachoreographyabono.core.business.AbonoNegocioInterface;
import com.bsoftgroup.springmssagachoreographyabono.dto.AbonoDto;
import com.bsoftgroup.springmssagachoreographyabono.dto.PagoDto;
import com.bsoftgroup.springmssagachoreographyabono.dto.TransaccionDto;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class Consumer {
	Logger logger = LoggerFactory.getLogger(Consumer.class);
	
	@Autowired
    ObjectMapper objectMapper;
	
	@Autowired
	private AbonoNegocioInterface service;
	
	//@KafkaListener(topics = {"pago-events"})
	public void onMessage(ConsumerRecord<Integer,String> consumerRecord) throws JsonProcessingException {
		logger.info("ConsumerRecord : {} ", consumerRecord );
        //libraryEventsService.processLibraryEvent(consumerRecord);
    	PagoDto pago = objectMapper.readValue(consumerRecord.value(), PagoDto.class);
    	
		AbonoDto abono = new AbonoDto();
		abono.setCausal(pago.getCausal());
		abono.setCliente(pago.getAcreedor());
		abono.setCuenta(pago.getCuentaabono());
		abono.setMonto(pago.getMonto());
		abono.setPagador(pago.getPagador());
		abono.setTransaccion(consumerRecord.key().toString());
		TransaccionDto txabono= new TransaccionDto();
    	try {
    		txabono = service.procesarAbono(abono.getCuenta(), abono.getMonto(),abono.getCliente(), abono.getTransaccion(), abono.getCausal(), abono.getPagador());
		
    		 if(txabono.getCodigo().equals("000")) {
    			 logger.info("proceso de Abono : {} ", txabono.getDescripcion() );

             }else {
            	 logger.info("proceso de Abono : {} ", txabono.getDescripcion() );
 			}
    	} catch (AppException e) {
			// TODO Auto-generated catch block
    		 logger.info("proceso de Abono : {} ", e.getMessage() );
			//reversa
		}
    	
    	logger.info("maensaje {}",pago);
		
	}
	
	
    @KafkaListener(groupId="${spring.kafka.consumer.group-id}", topics = "${spring.kafka.template.default-topic}")
    //@SendTo
    public void listen(ConsumerRecord<Integer, String> consumerRecord) {
    	//logger.info("valor de la información ",consumerRecord.value());
        //String reversedString = new StringBuilder( String.valueOf(consumerRecord.value()) ).reverse().toString();
        //logger.info("ConsumerRecord : {} ", consumerRecord );
        //libraryEventsService.processLibraryEvent(consumerRecord);
    	
		TransaccionDto txabono= new TransaccionDto();
    	String value=null;
    	
    	try {
		
        PagoDto pago = objectMapper.readValue(consumerRecord.value(), PagoDto.class);
    	
		AbonoDto abono = new AbonoDto();
		abono.setCausal(pago.getCausal());
		abono.setCliente(pago.getAcreedor());
		abono.setCuenta(pago.getCuentaabono());
		abono.setMonto(pago.getMonto());
		abono.setPagador(pago.getPagador());
		abono.setTransaccion(consumerRecord.key().toString());

    
    		txabono = service.procesarAbono(abono.getCuenta(), abono.getMonto(),abono.getCliente(), abono.getTransaccion(), abono.getCausal(), abono.getPagador());
    		value=objectMapper.writeValueAsString(txabono);
    		 if(txabono.getCodigo().equals("000")) {
    			 logger.info("proceso de cargo : {} ", txabono.getDescripcion() );

             }else {
            	 logger.info("proceso de cargo : {} ", txabono.getDescripcion() );
 			}
    	}catch (JsonProcessingException je) {
			// TODO: handle exception
    		 logger.info("proceso de cargo : {} ", je.getMessage() );
		} catch (AppException e) {
			// TODO Auto-generated catch block
    		 logger.info("proceso de cargo : {} ", e.getMessage() );
			//reversa
		}
    	
    	
    	
        /*return MessageBuilder.withPayload( value )
                .build();*/
    }

}