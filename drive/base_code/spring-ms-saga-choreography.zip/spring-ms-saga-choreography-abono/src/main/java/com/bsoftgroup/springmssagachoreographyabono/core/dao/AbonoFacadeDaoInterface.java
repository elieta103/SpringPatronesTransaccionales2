package com.bsoftgroup.springmssagachoreographyabono.core.dao;

import java.math.BigDecimal;

import com.bsoftgroup.springmssagachoreographyabono.configuration.AppException;
import com.bsoftgroup.springmssagachoreographyabono.dto.ReversionDto;
import com.bsoftgroup.springmssagachoreographyabono.dto.TransaccionDto;
import com.fasterxml.jackson.core.JsonProcessingException;

public interface AbonoFacadeDaoInterface {

	 public void revertirAbono(ReversionDto reversion, Integer transaccion) throws JsonProcessingException;
	 public TransaccionDto procesarAbono(String cuenta,BigDecimal monto, String cliente,String transaccion,String causal,String pagador) throws AppException;
}
