package com.bsoftgroup.springmssagachoreographyabono.core.dao.kafka;


import com.bsoftgroup.springmssagachoreographyabono.dto.ReversionDto;
import com.fasterxml.jackson.core.JsonProcessingException;

public interface PublicadorInterface {
	
	 public void revertirAbono(ReversionDto reversion, Integer transaccion) throws JsonProcessingException;

}
