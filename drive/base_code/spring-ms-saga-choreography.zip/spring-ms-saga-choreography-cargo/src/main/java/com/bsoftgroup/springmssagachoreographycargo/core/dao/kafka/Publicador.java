package com.bsoftgroup.springmssagachoreographycargo.core.dao.kafka;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Component;
import org.springframework.util.concurrent.ListenableFuture;
import org.springframework.util.concurrent.ListenableFutureCallback;

import com.bsoftgroup.springmssagachoreographycargo.dto.ReversionDto;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class Publicador implements PublicadorInterface {
	
	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
    KafkaTemplate<Integer,String> kafkaTemplate;
	
	
	
	@Value("${ms-topic.reversa.cargo}")
    private String TOPIC_REVERSE_CARGO;
	

	@Value("${ms-topic.reversa.abono}")
    private String TOPIC_REVERSE_ABONO;
	
	

	 @Autowired
	 ObjectMapper objectMapper;

	@Override
	 public void revertirCargo(ReversionDto reversion, Integer transaccion) throws JsonProcessingException{
		 Integer key=transaccion;
		 String value=objectMapper.writeValueAsString(reversion);
		
		ListenableFuture<SendResult<Integer,String>> listenableFuture =  kafkaTemplate.send(TOPIC_REVERSE_CARGO, key, value);
		listenableFuture.addCallback(new ListenableFutureCallback<SendResult<Integer, String>>() {
	            @Override
	            public void onFailure(Throwable ex) {
	                handleFailure(key, value, ex);//
	                //
	            }

	            @Override
	            public void onSuccess(SendResult<Integer, String> result) {
	                handleSuccess(key, value, result);
	                logger.info("Se genero el pedido de reversa de modo conforme {}");
	            }
	        });

	 }
	
	@Override
	 public void revertirAbono(ReversionDto reversion, Integer transaccion) throws JsonProcessingException{
		 Integer key=transaccion;
		 String value=objectMapper.writeValueAsString(reversion);
		 
		ListenableFuture<SendResult<Integer,String>> listenableFuture =  kafkaTemplate.send(TOPIC_REVERSE_ABONO, key, value);
		listenableFuture.addCallback(new ListenableFutureCallback<SendResult<Integer, String>>() {
	            @Override
	            public void onFailure(Throwable ex) {
	                handleFailure(key, value, ex);//
	                //
	            }

	            @Override
	            public void onSuccess(SendResult<Integer, String> result) {
	                handleSuccess(key, value, result);
	                logger.info("Se genero el pedido de reversa de modo conforme {}");
	            }
	        });

	 }
	 
	 private void handleFailure(Integer key, String value, Throwable ex) {
		 logger.error("Error Sending the Message and the exception is {}", ex.getMessage());
	        try {
	            throw ex;
	        } catch (Throwable throwable) {
	        	logger.error("Error in OnFailure: {}", throwable.getMessage());
	        }


	    }

	    private void handleSuccess(Integer key, String value, SendResult<Integer, String> result) {
	    	logger.info("Message Sent SuccessFully for the key : {} and the value is {} , partition is {}", key, value, result.getRecordMetadata().partition());
	    }
	 
	
	 
}