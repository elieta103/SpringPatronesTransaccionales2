package com.bsoftgroup.springmssagachoreographycargo.core.business;

import java.math.BigDecimal;

import com.bsoftgroup.springmssagachoreographycargo.configuration.AppException;
import com.bsoftgroup.springmssagachoreographycargo.dto.TransaccionDto;



public interface CargoBusinessInterface {
	
	public TransaccionDto generarCargoCuenta(String cuenta, BigDecimal monto,String cliente,String causal,String acreedor,String transaccion) throws AppException;

}