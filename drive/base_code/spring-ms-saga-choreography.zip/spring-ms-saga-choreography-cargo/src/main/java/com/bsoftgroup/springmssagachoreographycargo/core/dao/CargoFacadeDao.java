package com.bsoftgroup.springmssagachoreographycargo.core.dao;

import java.math.BigDecimal;

import org.springframework.stereotype.Component;

import com.bsoftgroup.springmssagachoreographycargo.configuration.AppException;
import com.bsoftgroup.springmssagachoreographycargo.core.dao.kafka.PublicadorInterface;
import com.bsoftgroup.springmssagachoreographycargo.core.dao.sql.CargoSqlDaoInterface;
import com.bsoftgroup.springmssagachoreographycargo.dto.ReversionDto;
import com.bsoftgroup.springmssagachoreographycargo.dto.TransaccionDto;
import com.fasterxml.jackson.core.JsonProcessingException;

@Component
public class CargoFacadeDao implements CargoFacadeDaoInterface {
	
	private final PublicadorInterface kafka;
	private final CargoSqlDaoInterface sql;

	
	
	public CargoFacadeDao(CargoSqlDaoInterface sql, PublicadorInterface kafka) {
		this.kafka = kafka;
		this.sql = sql;
		
	}

	@Override
	public TransaccionDto generarCargoCuenta(String cuenta, BigDecimal monto, String cliente, String causal,
			String acreedor, String transaccion) throws AppException {
		// TODO Auto-generated method stub
		return sql.generarCargoCuenta(cuenta, monto, cliente, causal, acreedor, transaccion);
	}

	@Override
	public void revertirCargo(ReversionDto reversion, Integer transaccion) throws JsonProcessingException {
		// TODO Auto-generated method stub
		kafka.revertirCargo(reversion, transaccion);
		
	}

	@Override
	public void revertirAbono(ReversionDto reversion, Integer transaccion) throws JsonProcessingException {
		// TODO Auto-generated method stub
		kafka.revertirAbono(reversion, transaccion);
	}

}
