package com.bsoftgroup.springmssagachoreographycargo.core.business;

import java.math.BigDecimal;


import org.springframework.stereotype.Service;

import com.bsoftgroup.springmssagachoreographycargo.configuration.AppException;
import com.bsoftgroup.springmssagachoreographycargo.core.dao.CargoFacadeDaoInterface;
import com.bsoftgroup.springmssagachoreographycargo.dto.ReversionDto;
import com.bsoftgroup.springmssagachoreographycargo.dto.TransaccionDto;
import com.fasterxml.jackson.core.JsonProcessingException;


@Service
public class CargoBusiness implements CargoBusinessInterface{
	
	private final CargoFacadeDaoInterface dao;
	
	public CargoBusiness(CargoFacadeDaoInterface dao) {
		this.dao = dao;
		
	}

	@Override
	public TransaccionDto generarCargoCuenta(String cuenta, BigDecimal monto, String cliente, String causal,
			String acreedor, String transaccion) throws AppException {
		// TODO Auto-generated method stub
		

		TransaccionDto trx = new TransaccionDto();

		try {
			trx= dao.generarCargoCuenta(cuenta, monto, cliente, causal, acreedor, transaccion);
		    //generar reversa if(trx.getCodigo().equals("000")) {
		    if(!trx.getCodigo().equals("000")) {
                ReversionDto reversa = new ReversionDto();
				reversa.setTransaccion(transaccion);
				
				try {
					reversa.setCausal("CARGO");
					dao.revertirCargo(reversa, Integer.valueOf(transaccion));
					
					reversa.setCausal("ABONO");
					dao.revertirAbono(reversa, Integer.valueOf(transaccion));
					
				} catch (JsonProcessingException | NumberFormatException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				trx.setCodigo("788");
				trx.setDescripcion("Revirtiendo el cargo y abono");
				
		    }
		} catch (AppException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();

			throw new AppException(e.getMessage());
		}
		return trx;
	}




}