package com.bsoftgroup.springmssagachoreographycargo.core.dao.sql;

import java.math.BigDecimal;

import com.bsoftgroup.springmssagachoreographycargo.configuration.AppException;
import com.bsoftgroup.springmssagachoreographycargo.dto.TransaccionDto;





public interface CargoSqlDaoInterface {
	
	public TransaccionDto generarCargoCuenta(String cuenta, BigDecimal monto,String cliente,String causal,String acreedor,String transaccion) throws AppException;

}