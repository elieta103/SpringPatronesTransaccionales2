package com.bsoftgroup.springmssagachoreographycargo.core.dao;

import java.math.BigDecimal;

import com.bsoftgroup.springmssagachoreographycargo.configuration.AppException;
import com.bsoftgroup.springmssagachoreographycargo.dto.ReversionDto;
import com.bsoftgroup.springmssagachoreographycargo.dto.TransaccionDto;
import com.fasterxml.jackson.core.JsonProcessingException;

public interface CargoFacadeDaoInterface {
	public TransaccionDto generarCargoCuenta(String cuenta, BigDecimal monto,String cliente,String causal,String acreedor,String transaccion) throws AppException;
	public void revertirCargo(ReversionDto reversion, Integer transaccion) throws JsonProcessingException;
	public void revertirAbono(ReversionDto reversion, Integer transaccion) throws JsonProcessingException;
}
