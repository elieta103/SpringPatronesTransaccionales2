package com.bsoftgroup.springmssagachoreographycargo.core.dao.kafka;

import com.bsoftgroup.springmssagachoreographycargo.dto.ReversionDto;
import com.fasterxml.jackson.core.JsonProcessingException;

public interface PublicadorInterface {
	
	 public void revertirCargo(ReversionDto reversion, Integer transaccion) throws JsonProcessingException;
	 public void revertirAbono(ReversionDto reversion, Integer transaccion) throws JsonProcessingException;

}
